import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        paper: "#fbf8f1",
        ink: "#1d1b16",
        moss: "#2f5d3b",
        sage: "#d7e6d7",
        clay: "#b56b3f",
        frost: "#3b82f6"
      },
      boxShadow: {
        soft: "0 12px 30px rgba(0,0,0,.08)"
      }
    },
  },
  plugins: [],
};
export default config;
