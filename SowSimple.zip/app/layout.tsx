import "./globals.css";
import type { Metadata, Viewport } from "next";
import { Header } from "@/components/header";

export const metadata: Metadata = {
  title: "SowSimple — UK sowing by postcode",
  description: "A simple UK sowing guide based on your postcode, month and frost risk.",
  applicationName: "SowSimple",
  manifest: "/manifest.webmanifest",
  icons: [{ rel: "icon", url: "/icon.svg" }],
};

export const viewport: Viewport = {
  themeColor: "#2f5d3b",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <body>
        <div className="min-h-screen">
          <Header />
          <main className="mx-auto max-w-3xl px-4 pb-24 pt-4">{children}</main>
        </div>
      </body>
    </html>
  );
}
