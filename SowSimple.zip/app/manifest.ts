import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "SowSimple",
    short_name: "SowSimple",
    description: "UK sowing guide by postcode with frost warnings.",
    start_url: "/",
    display: "standalone",
    background_color: "#fbf8f1",
    theme_color: "#2f5d3b",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png" }
    ],
  };
}
