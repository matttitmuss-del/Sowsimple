import { CropsClient } from "@/components/crops-client";

export default function CropsPage() {
  return <CropsClient />;
}
