import { OnboardingGate } from "@/components/onboarding";
import { HomeClient } from "@/components/home-client";

export default function Page() {
  return (
    <OnboardingGate>
      <HomeClient />
    </OnboardingGate>
  );
}
