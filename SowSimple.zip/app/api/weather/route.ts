import { NextResponse } from "next/server";

type PostcodesIO = {
  status: number;
  result: {
    postcode: string;
    admin_district?: string;
    latitude: number;
    longitude: number;
  } | null;
};

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const postcodeRaw = (searchParams.get("postcode") || "").trim();
  const protection = searchParams.get("protection") === "1";

  if (!postcodeRaw) {
    return NextResponse.json({ message: "Postcode is required" }, { status: 400 });
  }

  const pc = postcodeRaw.toUpperCase().replace(/\s+/g, "");
  // Postcodes.io is free and UK-specific
  const geoRes = await fetch(`https://api.postcodes.io/postcodes/${encodeURIComponent(pc)}`, { cache: "no-store" });
  if (!geoRes.ok) {
    return NextResponse.json({ message: "Postcode lookup failed" }, { status: 400 });
  }
  const geo: PostcodesIO = await geoRes.json();
  if (!geo.result) {
    return NextResponse.json({ message: "Postcode not found" }, { status: 400 });
  }

  const lat = geo.result.latitude;
  const lon = geo.result.longitude;
  const area = geo.result.admin_district;

  // Open-Meteo is free and doesn't require a key.
  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&daily=temperature_2m_min,temperature_2m_max&forecast_days=7&timezone=Europe%2FLondon`;

  const wxRes = await fetch(url, { cache: "no-store" });
  if (!wxRes.ok) {
    return NextResponse.json({ message: "Weather fetch failed" }, { status: 500 });
  }
  const wx = await wxRes.json();

  const times: string[] = wx?.daily?.time ?? [];
  const mins: number[] = wx?.daily?.temperature_2m_min ?? [];
  const maxs: number[] = wx?.daily?.temperature_2m_max ?? [];

  const days = times.map((t, i) => ({
    date: t,
    tmin: typeof mins[i] === "number" ? mins[i] : NaN,
    tmax: typeof maxs[i] === "number" ? maxs[i] : NaN,
  })).filter(d => Number.isFinite(d.tmin) && Number.isFinite(d.tmax));

  // Frost threshold: if user has protection, be a bit more tolerant (warn only at 0°C),
  // otherwise warn at 2°C. You can tweak this.
  const frostThreshold = protection ? 0 : 2;
  const frostRisk = days.some(d => d.tmin <= frostThreshold);

  return NextResponse.json({
    postcode: geo.result.postcode,
    area,
    lat,
    lon,
    days,
    frostRisk,
    frostThreshold
  });
}
