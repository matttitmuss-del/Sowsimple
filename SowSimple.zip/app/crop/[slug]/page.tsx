import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { CROPS, monthsToText } from "@/lib/crops";
import { Card, CardBody, CardHeader, Pill } from "@/components/ui";

export default function CropPage({ params }: { params: { slug: string } }) {
  const crop = CROPS.find(c => c.slug === params.slug);
  if (!crop) return notFound();

  return (
    <div className="space-y-4">
      <Link href="/crops" className="inline-flex items-center gap-2 text-sm text-ink/70 hover:text-ink">
        <ArrowLeft size={16} /> Back to crops
      </Link>

      <Card className="overflow-hidden">
        <CardHeader
          title={crop.name}
          subtitle={crop.category}
          right={<Pill tone={crop.difficulty === "easy" ? "moss" : "clay"}>{crop.difficulty === "easy" ? "Beginner-friendly" : "Takes a bit more care"}</Pill>}
        />
        <CardBody className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="text-xs font-semibold text-ink/70">Sow indoors</div>
              <div className="mt-1 text-sm font-semibold">{monthsToText(crop.sow_indoor_months)}</div>
            </div>
            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="text-xs font-semibold text-ink/70">Sow outdoors</div>
              <div className="mt-1 text-sm font-semibold">{monthsToText(crop.sow_outdoor_months)}</div>
              <div className="mt-2 text-xs text-ink/60">Min temp: {crop.min_temp_outdoor}°C</div>
            </div>
            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="text-xs font-semibold text-ink/70">Harvest</div>
              <div className="mt-1 text-sm font-semibold">{monthsToText(crop.harvest_months)}</div>
            </div>
          </div>

          <div className="rounded-2xl border border-black/5 bg-white p-4">
            <div className="text-sm font-semibold">Beginner notes</div>
            <p className="mt-1 text-sm text-ink/75">{crop.beginner_notes}</p>
          </div>

          <div className="rounded-2xl border border-black/5 bg-white p-4">
            <div className="text-sm font-semibold">Quick tips</div>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-ink/80">
              {crop.growing_tips.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="text-xs font-semibold text-ink/70">Frost tolerance</div>
              <div className="mt-1 text-sm font-semibold">{crop.frost_tolerance}</div>
            </div>
            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="text-xs font-semibold text-ink/70">Spacing</div>
              <div className="mt-1 text-sm font-semibold">{crop.spacing_cm ?? "—"}</div>
            </div>
          </div>

          <div className="rounded-2xl border border-black/5 bg-sage p-4">
            <div className="text-sm font-semibold">Pro idea</div>
            <p className="mt-1 text-sm text-ink/75">
              Later we can generate a personal “bed plan” and weekly checklist for your exact setup (pots/raised beds/tunnel).
            </p>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
