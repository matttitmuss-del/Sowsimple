"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { AlertTriangle, ChevronRight, CloudSun, ThermometerSnowflake } from "lucide-react";
import { Card, CardBody, CardHeader, Pill } from "@/components/ui";
import { useSettings } from "@/lib/useSettings";
import { fetchWeather } from "@/lib/weather";
import { monthsToText, recommendForMonth } from "@/lib/crops";

function SectionList({ title, subtitle, items }: { title: string; subtitle?: string; items: { slug: string; name: string; beginner_notes: string }[] }) {
  return (
    <Card className="overflow-hidden">
      <CardHeader title={title} subtitle={subtitle} />
      <CardBody className="space-y-2">
        {items.length ? (
          <ul className="divide-y divide-black/5 overflow-hidden rounded-2xl border border-black/5 bg-paper">
            {items.map((c) => (
              <li key={c.slug}>
                <Link href={`/crop/${c.slug}`} className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-white">
                  <div>
                    <div className="font-medium">{c.name}</div>
                    <div className="text-xs text-ink/70 line-clamp-1">{c.beginner_notes}</div>
                  </div>
                  <ChevronRight size={18} className="text-ink/40" />
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-ink/70">Nothing recommended right now.</p>
        )}
      </CardBody>
    </Card>
  );
}

export function HomeClient() {
  const { settings } = useSettings();
  const [weatherState, setWeatherState] = useState<{ status: "idle" | "loading" | "ok" | "error"; message?: string; data?: any }>({ status: "idle" });

  const month = useMemo(() => new Date().getMonth() + 1, []);
  const rec = useMemo(() => recommendForMonth(month), [month]);

  useEffect(() => {
    if (!settings.postcode) return;
    setWeatherState({ status: "loading" });
    fetchWeather(settings.postcode, !!settings.protection)
      .then((data) => setWeatherState({ status: "ok", data }))
      .catch((e) => setWeatherState({ status: "error", message: e?.message || "Failed to load weather" }));
  }, [settings.postcode, settings.protection]);

  const outdoorsNow = useMemo(() => {
    // If frost risk, restrict outdoor suggestions to those with low min_temp_outdoor vs forecast mins.
    if (weatherState.status !== "ok") return rec.sowOutdoorsWindow;
    const days = weatherState.data?.days ?? [];
    const next3mins = days.slice(0, 3).map((d: any) => d.tmin);
    const minNext3 = next3mins.length ? Math.min(...next3mins) : 99;
    return rec.sowOutdoorsWindow.filter((c) => minNext3 >= c.min_temp_outdoor);
  }, [rec.sowOutdoorsWindow, weatherState.status, weatherState.data]);

  return (
    <div className="space-y-4">
      <Card className="overflow-hidden">
        <CardHeader
          title="Today’s plan"
          subtitle={settings.postcode ? `For ${settings.postcode} · Month ${month}` : "Set your postcode to personalise"}
          right={<Pill tone="moss">UK</Pill>}
        />
        <CardBody className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <CloudSun size={18} className="text-moss" /> Weather
              </div>
              {weatherState.status === "loading" ? (
                <p className="mt-2 text-sm text-ink/70">Loading forecast…</p>
              ) : weatherState.status === "error" ? (
                <p className="mt-2 text-sm text-clay">{weatherState.message}</p>
              ) : weatherState.status === "ok" ? (
                <div className="mt-2 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <Pill tone="sage">{weatherState.data?.area ?? "Local area"}</Pill>
                    <Pill tone="blue">7‑day</Pill>
                  </div>
                  <div className="text-sm text-ink/80">
                    Next 3 nights min:{" "}
                    <span className="font-semibold">
                      {weatherState.data.days
                        .slice(0, 3)
                        .map((d: any) => `${Math.round(d.tmin)}°`)
                        .join(", ")}
                    </span>
                  </div>
                </div>
              ) : (
                <p className="mt-2 text-sm text-ink/70">Enter a postcode to see local frost risk.</p>
              )}
            </div>

            <div className="rounded-2xl border border-black/5 bg-paper p-4">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <ThermometerSnowflake size={18} className="text-frost" /> Frost risk
              </div>
              {weatherState.status === "ok" ? (
                <div className="mt-2 space-y-2">
                  {weatherState.data.frostRisk ? (
                    <div className="rounded-2xl border border-frost/20 bg-frost/10 p-3">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="mt-0.5 text-frost" size={18} />
                        <div>
                          <div className="text-sm font-semibold text-frost">Frost risk soon</div>
                          <div className="text-xs text-ink/70">
                            Overnight lows below {weatherState.data.frostThreshold}°C. Protect seedlings (fleece/cloche) and avoid planting tender crops out.
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-2xl border border-black/5 bg-white p-3 text-sm text-ink/80">
                      No frost flagged (threshold {weatherState.data.frostThreshold}°C).
                    </div>
                  )}
                  <div className="text-xs text-ink/60">
                    Outdoor sowing below is filtered by crop minimum temperature for the next 3 nights.
                  </div>
                </div>
              ) : (
                <p className="mt-2 text-sm text-ink/70">We’ll show a warning when temperatures dip.</p>
              )}
            </div>
          </div>

          <div className="rounded-2xl border border-black/5 bg-white p-4">
            <div className="text-sm font-semibold">How this works</div>
            <p className="mt-1 text-sm text-ink/70">
              We use your postcode for a local forecast and match it to UK sowing windows. Tap a crop for full sow/harvest details and quick tips.
            </p>
          </div>
        </CardBody>
      </Card>

      <SectionList
        title="Sow indoors now"
        subtitle="Warm windowsill / greenhouse starts"
        items={rec.sowIndoorsNow as any}
      />
      <SectionList
        title="Sow outdoors now"
        subtitle="Filtered by forecast minimums"
        items={outdoorsNow as any}
      />
      <SectionList
        title="Coming soon"
        subtitle="Likely next month"
        items={rec.comingSoon as any}
      />
      <SectionList
        title="Harvest now"
        subtitle="If you already have crops in"
        items={rec.harvestNow as any}
      />

      <Card>
        <CardHeader title="Pro features (coming soon)" subtitle="Only build if people actually use v1." right={<Pill tone="clay">Locked</Pill>} />
        <CardBody>
          <ul className="list-disc pl-5 text-sm text-ink/80 space-y-1">
            <li>Personal planting planner (your beds/pots)</li>
            <li>Reminders and calendar export</li>
            <li>Crop success tracking (notes + photos)</li>
            <li>Monthly “what to do” checklist</li>
          </ul>
        </CardBody>
      </Card>
    </div>
  );
}
