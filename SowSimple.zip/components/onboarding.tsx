"use client";

import { useEffect, useMemo, useState } from "react";
import { Button, Card, CardBody, CardHeader, Input, Toggle } from "@/components/ui";
import { isLikelyUKPostcode, normalisePostcode } from "@/lib/postcode";
import { useSettings } from "@/lib/useSettings";

export function OnboardingGate({ children }: { children: React.ReactNode }) {
  const { settings, saveSettings } = useSettings();
  const [open, setOpen] = useState(false);
  const [postcode, setPostcode] = useState(settings.postcode ?? "");
  const [protection, setProtection] = useState(!!settings.protection);

  useEffect(() => {
    setOpen(!settings.postcode);
  }, [settings.postcode]);

  const valid = useMemo(() => isLikelyUKPostcode(postcode), [postcode]);

  function handleSave() {
    const pc = normalisePostcode(postcode);
    saveSettings({ postcode: pc, protection });
    setOpen(false);
  }

  return (
    <>
      {children}
      {open ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-4 sm:items-center">
          <div className="w-full max-w-lg">
            <Card>
              <CardHeader
                title="Welcome to SowSimple"
                subtitle="Your personalised UK sowing guide — based on your postcode, month and frost risk."
              />
              <CardBody className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm font-medium">Your postcode</label>
                  <Input value={postcode} onChange={setPostcode} placeholder="e.g. SG4 7NT" />
                  {!postcode ? null : valid ? (
                    <p className="mt-2 text-xs text-moss">Looks good.</p>
                  ) : (
                    <p className="mt-2 text-xs text-clay">That doesn’t look like a UK postcode.</p>
                  )}
                </div>
                <Toggle
                  checked={protection}
                  onChange={setProtection}
                  label="I have protection (cloche / fleece / cold frame)"
                />
                <div className="flex gap-2">
                  <Button className="w-full" onClick={handleSave} disabled={!valid}>
                    Start
                  </Button>
                </div>
                <p className="text-xs text-ink/60">
                  Tip: this is v1 — no logins, no spam. Your settings are stored only on this device.
                </p>
              </CardBody>
            </Card>
          </div>
        </div>
      ) : null}
    </>
  );
}
