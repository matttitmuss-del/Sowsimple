"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search } from "lucide-react";
import { CROPS } from "@/lib/crops";
import { Card, CardBody, CardHeader, Input, Pill } from "@/components/ui";

export function CropsClient() {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return CROPS;
    return CROPS.filter(c => c.name.toLowerCase().includes(s) || c.category.toLowerCase().includes(s));
  }, [q]);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader title="Crops" subtitle="Tap any crop for sowing + harvest details." right={<Pill tone="sage">{filtered.length}</Pill>} />
        <CardBody className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-ink/40" size={18} />
            <div className="pl-7">
              <Input value={q} onChange={setQ} placeholder="Search crops (e.g. tomatoes, peas, herbs)…" />
            </div>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            {filtered.map(c => (
              <Link key={c.slug} href={`/crop/${c.slug}`} className="rounded-2xl border border-black/5 bg-white p-4 hover:bg-paper">
                <div className="font-semibold">{c.name}</div>
                <div className="mt-1 text-xs text-ink/70">{c.category}</div>
                <div className="mt-2 text-xs text-ink/60 line-clamp-2">{c.beginner_notes}</div>
              </Link>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
