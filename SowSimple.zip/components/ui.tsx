import React from "react";

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={["rounded-3xl border border-black/5 bg-white shadow-soft", className].join(" ")}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 px-5 pt-5">
      <div>
        <h2 className="text-base font-semibold">{title}</h2>
        {subtitle ? <p className="mt-1 text-sm text-ink/70">{subtitle}</p> : null}
      </div>
      {right ? <div className="shrink-0">{right}</div> : null}
    </div>
  );
}

export function CardBody({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={["px-5 pb-5 pt-4", className].join(" ")}>{children}</div>;
}

export function Pill({ children, tone = "sage" }: { children: React.ReactNode; tone?: "sage" | "clay" | "blue" | "moss" }) {
  const cls =
    tone === "sage"
      ? "bg-sage text-ink"
      : tone === "clay"
      ? "bg-clay/15 text-clay"
      : tone === "blue"
      ? "bg-frost/10 text-frost"
      : "bg-moss/10 text-moss";
  return <span className={["inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium", cls].join(" ")}>{children}</span>;
}

export function Button({
  children,
  onClick,
  type = "button",
  variant = "primary",
  className = "",
  disabled
}: {
  children: React.ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  variant?: "primary" | "ghost";
  className?: string;
  disabled?: boolean;
}) {
  const base = "inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-semibold transition";
  const styles =
    variant === "primary"
      ? "bg-moss text-paper hover:bg-moss/90 disabled:opacity-50"
      : "bg-transparent text-ink hover:bg-sage disabled:opacity-50";
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={[base, styles, className].join(" ")}>
      {children}
    </button>
  );
}

export function Input({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-2xl border border-black/10 bg-white px-4 py-2 text-sm outline-none focus:border-moss"
    />
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex items-center justify-between gap-3 rounded-2xl border border-black/5 bg-paper px-4 py-3">
      <span className="text-sm font-medium">{label}</span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={[
          "relative h-7 w-12 rounded-full transition",
          checked ? "bg-moss" : "bg-black/20"
        ].join(" ")}
        aria-pressed={checked}
      >
        <span
          className={[
            "absolute top-1 h-5 w-5 rounded-full bg-white transition",
            checked ? "left-6" : "left-1"
          ].join(" ")}
        />
      </button>
    </label>
  );
}
