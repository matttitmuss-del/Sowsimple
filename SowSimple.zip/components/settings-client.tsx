"use client";

import { useMemo, useState } from "react";
import { useSettings } from "@/lib/useSettings";
import { Button, Card, CardBody, CardHeader, Input, Toggle } from "@/components/ui";
import { isLikelyUKPostcode, normalisePostcode } from "@/lib/postcode";

export function SettingsClient() {
  const { settings, saveSettings, reset } = useSettings();
  const [postcode, setPostcode] = useState(settings.postcode ?? "");
  const [protection, setProtection] = useState(!!settings.protection);

  const valid = useMemo(() => isLikelyUKPostcode(postcode), [postcode]);

  function save() {
    saveSettings({ postcode: normalisePostcode(postcode), protection });
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader title="Settings" subtitle="Stored only on this device (no account required)." />
        <CardBody className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium">Postcode</label>
            <Input value={postcode} onChange={setPostcode} placeholder="e.g. SG4 7NT" />
            {!postcode ? null : valid ? (
              <p className="mt-2 text-xs text-moss">Looks good.</p>
            ) : (
              <p className="mt-2 text-xs text-clay">That doesn’t look like a UK postcode.</p>
            )}
          </div>

          <Toggle checked={protection} onChange={setProtection} label="I have protection (cloche / fleece / cold frame)" />

          <div className="flex gap-2">
            <Button onClick={save} disabled={!valid} className="flex-1">
              Save
            </Button>
            <Button variant="ghost" onClick={reset}>
              Reset
            </Button>
          </div>

          <div className="rounded-2xl border border-black/5 bg-paper p-4 text-sm text-ink/75">
            <div className="font-semibold">About frost</div>
            <p className="mt-1">
              We flag frost risk when the forecast overnight minimum drops below a threshold. If you have protection enabled,
              we use a stricter threshold (more tolerant).
            </p>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
