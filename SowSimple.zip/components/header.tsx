"use client";

import Link from "next/link";
import { Sprout, Search, Settings } from "lucide-react";
import { usePathname } from "next/navigation";

function NavLink({ href, label, Icon }: { href: string; label: string; Icon: any }) {
  const pathname = usePathname();
  const active = pathname === href;
  return (
    <Link
      href={href}
      className={[
        "inline-flex items-center gap-2 rounded-full px-3 py-2 text-sm",
        active ? "bg-sage text-ink" : "text-ink/80 hover:bg-sage/60"
      ].join(" ")}
    >
      <Icon size={16} />
      <span className="hidden sm:inline">{label}</span>
    </Link>
  );
}

export function Header() {
  return (
    <header className="sticky top-0 z-20 border-b border-black/5 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
        <Link href="/" className="inline-flex items-center gap-2 font-semibold">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-moss text-paper shadow-soft">
            <Sprout size={18} />
          </span>
          <span>SowSimple</span>
        </Link>
        <nav className="flex items-center gap-2">
          <NavLink href="/" label="Today" Icon={Sprout} />
          <NavLink href="/crops" label="Crops" Icon={Search} />
          <NavLink href="/settings" label="Settings" Icon={Settings} />
        </nav>
      </div>
    </header>
  );
}
