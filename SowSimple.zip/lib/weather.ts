export type WeatherDay = {
  date: string; // YYYY-MM-DD
  tmin: number;
  tmax: number;
};

export type WeatherPayload = {
  postcode: string;
  area?: string;
  lat: number;
  lon: number;
  days: WeatherDay[];
  frostRisk: boolean;
  frostThreshold: number;
  message?: string;
};

export async function fetchWeather(postcode: string, protection: boolean): Promise<WeatherPayload> {
  const res = await fetch(`/api/weather?postcode=${encodeURIComponent(postcode)}&protection=${protection ? "1" : "0"}`, { cache: "no-store" });
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new Error(j?.message || "Weather fetch failed");
  }
  return res.json();
}
