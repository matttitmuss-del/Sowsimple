"use client";

import { useLocalStorageState } from "@/lib/useLocalStorage";

export type SowSimpleSettings = {
  postcode?: string;
  protection?: boolean; // cloche/fleece etc
};

const KEY = "sowsimple_settings_v1";

export function useSettings() {
  const [settings, setSettings] = useLocalStorageState<SowSimpleSettings>(KEY, {});
  function saveSettings(partial: SowSimpleSettings) {
    setSettings({ ...settings, ...partial });
  }
  function reset() {
    setSettings({});
  }
  return { settings, saveSettings, reset };
}
