import crops from "@/data/crops.json";

export type Crop = {
  slug: string;
  name: string;
  category: string;
  sow_indoor_months: number[];
  sow_outdoor_months: number[];
  harvest_months: number[];
  frost_tolerance: "low" | "medium" | "high";
  min_temp_outdoor: number;
  difficulty: "easy" | "medium";
  beginner_notes: string;
  growing_tips: string[];
  spacing_cm?: string;
};

export const CROPS: Crop[] = crops as Crop[];

export function monthName(m: number): string {
  return ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][m-1] ?? "";
}

export function monthsToText(months: number[]): string {
  if (!months?.length) return "—";
  const sorted = [...months].sort((a,b)=>a-b);
  // compress consecutive ranges
  const ranges: Array<[number,number]> = [];
  let start = sorted[0], prev = sorted[0];
  for (let i=1;i<sorted.length;i++){
    const cur = sorted[i];
    if (cur === prev+1){ prev = cur; continue; }
    ranges.push([start, prev]);
    start = prev = cur;
  }
  ranges.push([start, prev]);
  return ranges.map(([a,b]) => a===b ? monthName(a) : `${monthName(a)}–${monthName(b)}`).join(", ");
}

export function recommendForMonth(month: number) {
  const next = month === 12 ? 1 : month + 1;
  const sowIndoorsNow = CROPS.filter(c => c.sow_indoor_months.includes(month)).sort((a,b)=>a.name.localeCompare(b.name));
  const sowOutdoorsWindow = CROPS.filter(c => c.sow_outdoor_months.includes(month)).sort((a,b)=>a.name.localeCompare(b.name));
  const comingSoon = CROPS.filter(c => c.sow_indoor_months.includes(next) || c.sow_outdoor_months.includes(next))
    .filter(c => !(c.sow_indoor_months.includes(month) || c.sow_outdoor_months.includes(month)))
    .sort((a,b)=>a.name.localeCompare(b.name));
  const harvestNow = CROPS.filter(c => c.harvest_months.includes(month)).sort((a,b)=>a.name.localeCompare(b.name));
  return { sowIndoorsNow, sowOutdoorsWindow, comingSoon, harvestNow };
}
