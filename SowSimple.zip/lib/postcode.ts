export function normalisePostcode(input: string): string {
  const s = input.trim().toUpperCase().replace(/\s+/g, "");
  if (s.length <= 3) return s;
  return s.slice(0, s.length - 3) + " " + s.slice(-3);
}

export function isLikelyUKPostcode(input: string): boolean {
  const pc = normalisePostcode(input);
  // Very forgiving UK postcode regex
  return /^[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}$/.test(pc);
}
