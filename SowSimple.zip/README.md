# SowSimple (Next.js PWA)

A simple UK sowing guide by postcode (weather + frost warning) with a built-in crop database.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Deploy (free)
- Vercel (recommended): import the repo and click Deploy.
- Or run on any Node host that supports Next.js.

## Notes
- Postcode lookup: https://postcodes.io (free)
- Weather: https://open-meteo.com (free, no key)
- Settings are stored only in the browser (localStorage).
